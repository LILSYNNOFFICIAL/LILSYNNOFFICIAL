LIL SYNN - Slack emoji (100)
128x128 PNG with transparent backgrounds.
HOW TO ADD: In Slack, click your workspace name > Tools & settings > Customize workspace > Emoji > Add Custom Emoji.
Upload a file and give it a name (the file name works, e.g. lilsynn_heart_hands). Your workspace may limit who can add emoji.

LICENSE: Free for personal use. Please don't sell these, put them on merch, or use them commercially.
Art (c) LIL SYNN / SYNTIENT RECORDS - lilsynn.com
