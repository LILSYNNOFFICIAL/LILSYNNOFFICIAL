LIL SYNN - generic emoji set (100)
72x72 PNG with transparent backgrounds. Works for forums, Mastodon/Matrix custom emoji,
streaming overlays, Guilded, Revolt, or anywhere that takes small custom emoji.
Upload them wherever your app's custom-emoji setting is.

LICENSE: Free for personal use. Please don't sell these, put them on merch, or use them commercially.
Art (c) LIL SYNN / SYNTIENT RECORDS - lilsynn.com
