LIL SYNN - Discord emoji (100 static + 10 animated static + animated)
All files are 128x128 and under 256 KB, so Discord accepts them as-is.
HOW TO ADD (you need 'Manage Expressions' on the server):
1. Server Settings > Emoji > Upload Emoji.
2. Pick files from this folder. The file name becomes the emoji name (e.g. :lilsynn_heart_hands:).
3. Animated GIFs (in the gifs folder) need a server with animated emoji slots (any server can add some; Nitro boosts add more).
Normal servers have 50 static slots, so pick your favorites.

LICENSE: Free for personal use. Please don't sell these, put them on merch, or use them commercially.
Art (c) LIL SYNN / SYNTIENT RECORDS - lilsynn.com
