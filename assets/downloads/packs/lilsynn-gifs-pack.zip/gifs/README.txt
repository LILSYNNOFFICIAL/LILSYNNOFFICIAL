LIL SYNN DOWNLOAD KIT  -  lilsynn.com/gallery
Free for personal use (wallpapers, chats, servers, fan posts). Please don't sell these or use them commercially.

discord/   128x128 PNG emoji + 128px animated GIF emoji (Server Settings > Emoji > Upload)
slack/     128x128 PNG emoji (Customize workspace > Emoji > Add custom emoji)
telegram/  512x512 PNG stickers (send to @Stickers bot: /newpack)
whatsapp/  512x512 WebP stickers (<100 KB each) + 96x96 tray_icon.png, for use with a sticker-maker app
stickers/  12 transparent 512x512 PNG stickers
gifs/      4 animated sticker GIFs
