LIL SYNN - Facebook Messenger pack (100 stickers + animated GIFs)
Heads up: Messenger doesn't let anyone upload custom sticker packs, so these can't go into
Messenger's sticker tray. They send as images (PNG) or animated GIFs instead - they still look
like stickers in the chat, because the backgrounds are transparent.
HOW TO SEND:
- Phone: save the files to your camera roll / gallery first (unzip, open, Save Image).
  In a Messenger chat tap the photo/gallery button, pick the sticker or GIF, and send.
- Computer: in a Messenger chat click the photo/attach button and choose the file,
  or just drag the file into the chat.
Folders: stickers/ = 512x512 transparent PNGs, gifs/ = animated GIFs.

LICENSE: Free for personal use. Please don't sell these, put them on merch, or use them commercially.
Art (c) LIL SYNN / SYNTIENT RECORDS - lilsynn.com
