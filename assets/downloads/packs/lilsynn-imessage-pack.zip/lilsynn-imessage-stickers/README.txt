LIL SYNN - Apple iMessage-ready stickers (100)
408x408 PNG (Apple's 'large' sticker size), transparent backgrounds.
EASIEST WAY: on iPhone (iOS 17+), save a PNG to Photos, open it, press and hold the character,
tap 'Add Sticker'. It then appears in your iMessage sticker drawer.
For developers: these drop straight into an Xcode Sticker Pack app.

LICENSE: Free for personal use. Please don't sell these, put them on merch, or use them commercially.
Art (c) LIL SYNN / SYNTIENT RECORDS - lilsynn.com
