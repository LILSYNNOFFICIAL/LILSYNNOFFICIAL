LIL SYNN - WhatsApp stickers (100, split into 4 packs of 25)
Each sticker is 512x512 WebP under 100 KB; each pack folder has a 96x96 tray icon.
WhatsApp packs hold 3-30 stickers, which is why there are 4 folders.
HOW TO ADD: WhatsApp doesn't import loose files directly. Use a free sticker-maker app
(search 'Sticker Maker' in the App Store / Google Play), create a pack, add the WebP files
from one folder and use tray_icon_96.png as the tray icon, then tap 'Add to WhatsApp'.

LICENSE: Free for personal use. Please don't sell these, put them on merch, or use them commercially.
Art (c) LIL SYNN / SYNTIENT RECORDS - lilsynn.com
