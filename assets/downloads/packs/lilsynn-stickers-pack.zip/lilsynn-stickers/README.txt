LIL SYNN - 100 stickers
512x512 transparent PNGs: LIL SYNN, the cat, Shadow Man, the girl, and icons.
Use them anywhere you can send or upload an image. Platform-ready packs (Discord, Slack, Twitch, Telegram, WhatsApp, iMessage, Messenger) are on lilsynn.com/gallery.

LICENSE: Free for personal use. Please don't sell these, put them on merch, or use them commercially.
Art (c) LIL SYNN / SYNTIENT RECORDS - lilsynn.com
