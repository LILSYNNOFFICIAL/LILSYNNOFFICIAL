LIL SYNN - Telegram stickers (100)
512x512 PNG with transparent backgrounds, the size Telegram wants.
HOW TO MAKE THE PACK: open a chat with @Stickers in Telegram, send /newpack, name it,
then send each PNG as a FILE (not as a photo) followed by an emoji for it. Send /publish when done.

LICENSE: Free for personal use. Please don't sell these, put them on merch, or use them commercially.
Art (c) LIL SYNN / SYNTIENT RECORDS - lilsynn.com
