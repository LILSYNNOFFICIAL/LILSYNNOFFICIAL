LIL SYNN - Twitch emotes (100, each in 112, 56 and 28 px)
HOW TO ADD (Affiliate/Partner channels): Creator Dashboard > Viewer Rewards > Emotes > upload.
Choose manual upload and add the 112x112, 56x56 and 28x28 versions of the same emote.
(Twitch can also auto-resize from the 112 file.) Emotes are reviewed by Twitch before going live.

LICENSE: Free for personal use. Please don't sell these, put them on merch, or use them commercially.
Art (c) LIL SYNN / SYNTIENT RECORDS - lilsynn.com
